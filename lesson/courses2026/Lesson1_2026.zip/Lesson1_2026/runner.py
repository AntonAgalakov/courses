import pathlib
import subprocess
import sys
import tempfile
import time


# Обёртка: тихо подменяет input(), чтобы подсказки не попадали в stdout.
WRAPPER = '''\
import builtins, runpy, sys

_real_input = builtins.input

def _silent_input(prompt=""):
    return _real_input()

builtins.input = _silent_input
runpy.run_path(sys.argv[1], run_name="__main__")
'''


def normalize(s: str) -> str:
    return "\n".join(line.rstrip() for line in s.strip().splitlines())


def run_solution(code: str, inp: str, timeout: float = 3.0):
    with tempfile.TemporaryDirectory() as d:
        d = pathlib.Path(d)
        (d / "solution.py").write_text(code, encoding="utf-8")
        (d / "_wrapper.py").write_text(WRAPPER, encoding="utf-8")

        start = time.time()
        try:
            p = subprocess.run(
                [sys.executable, "_wrapper.py", "solution.py"],
                input=inp,
                text=True,
                capture_output=True,
                timeout=timeout,
                cwd=d,
            )
            return {
                "ok": p.returncode == 0,
                "stdout": p.stdout,
                "stderr": p.stderr,
                "time": time.time() - start,
                "timeout": False,
            }
        except subprocess.TimeoutExpired:
            return {
                "ok": False,
                "stdout": "",
                "stderr": "Превышено время выполнения",
                "time": timeout,
                "timeout": True,
            }


def check_task(code: str, task: dict):
    results = []
    all_ok = True

    for i, t in enumerate(task["tests"], 1):
        r = run_solution(code, t["input"])
        expected = normalize(t["output"])
        actual = normalize(r["stdout"])

        if r["timeout"]:
            status, message = "timeout", "Превышено время"
            all_ok = False
        elif not r["ok"]:
            status, message = "error", r["stderr"].strip() or "Ошибка выполнения"
            all_ok = False
        elif actual != expected:
            status = "wrong"
            message = f"Ожидалось: {expected!r}, получено: {actual!r}"
            all_ok = False
        else:
            status, message = "ok", "OK"

        results.append({
            "n": i,
            "status": status,
            "message": message,
            "time": round(r["time"], 3),
        })

    return all_ok, results