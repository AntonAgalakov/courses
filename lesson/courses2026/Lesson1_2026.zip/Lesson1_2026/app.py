import datetime
import json
import pathlib

from flask import Flask, abort, jsonify, render_template, request

from runner import check_task
from tasks import TASKS

app = Flask(__name__)

PROGRESS_FILE = pathlib.Path("progress.json")
ACTIVITY_FILE = pathlib.Path("last_activity.txt")
IDLE_TIMEOUT = datetime.timedelta(minutes=30)


# ---------- прогресс ----------

def load_progress() -> dict:
    if PROGRESS_FILE.exists():
        try:
            return json.loads(PROGRESS_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_progress(data: dict) -> None:
    PROGRESS_FILE.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def find_task(task_id: str):
    return next((t for t in TASKS if t["id"] == task_id), None)


# ---------- автосброс по неактивности ----------

@app.before_request
def check_idle():
    now = datetime.datetime.now()

    if ACTIVITY_FILE.exists():
        try:
            last = datetime.datetime.fromisoformat(
                ACTIVITY_FILE.read_text(encoding="utf-8").strip()
            )
        except (ValueError, OSError):
            last = now

        if now - last > IDLE_TIMEOUT:
            if PROGRESS_FILE.exists():
                PROGRESS_FILE.unlink()

    ACTIVITY_FILE.write_text(now.isoformat(), encoding="utf-8")


# ---------- маршруты ----------

@app.route("/")
def index():
    progress = load_progress()
    # решёнными считаем только те, где solved == True
    solved = {tid for tid, entry in progress.items() if entry.get("solved")}

    topics = {}
    for t in TASKS:
        topic = t.get("topic", "Без темы")
        topics.setdefault(topic, {"total": 0, "solved": 0})
        topics[topic]["total"] += 1
        if t["id"] in solved:
            topics[topic]["solved"] += 1

    return render_template(
        "index.html",
        tasks=TASKS,
        solved=solved,
        topics=topics,
    )


@app.route("/task/<task_id>")
def task_page(task_id):
    task = find_task(task_id)
    if not task:
        abort(404)

    progress = load_progress()
    entry = progress.get(task_id, {})
    return render_template("task.html", task=task, entry=entry)


@app.route("/check/<task_id>", methods=["POST"])
def check(task_id):
    task = find_task(task_id)
    if not task:
        return jsonify({"ok": False, "error": "Задача не найдена"}), 404

    data = request.get_json() or {}
    code = data.get("code", "")
    if not code.strip():
        return jsonify({
            "ok": False,
            "results": [
                {"n": 0, "status": "error", "message": "Пустой код", "time": 0}
            ],
        })

    ok, results = check_task(code, task)

    progress = load_progress()
    entry = progress.get(task_id, {
        "solved": False,
        "attempts": 0,
        "best_passed": 0,
        "total": len(task["tests"]),
    })
    entry["attempts"] = entry.get("attempts", 0) + 1
    entry["last_check"] = datetime.datetime.now().isoformat(timespec="seconds")
    passed = sum(1 for r in results if r["status"] == "ok")
    entry["best_passed"] = max(entry.get("best_passed", 0), passed)
    entry["total"] = len(task["tests"])
    if ok:
        entry["solved"] = True
    # если не ok — solved остаётся False (или каким был)
    # специально НЕ сбрасываем True → False, чтобы решённое не «разрешалось»

    progress[task_id] = entry
    save_progress(progress)

    return jsonify({"ok": ok, "results": results})


@app.route("/reset", methods=["POST"])
def reset():
    if PROGRESS_FILE.exists():
        PROGRESS_FILE.unlink()
    if ACTIVITY_FILE.exists():
        ACTIVITY_FILE.unlink()
    return {"ok": True}


@app.route("/export")
def export():
    return jsonify(load_progress())


if __name__ == "__main__":
    app.run(debug=True)