# DataConverter — учебный проект для лабораторной по CI/CD

DataConverter — готовый учебный CLI-проект для конвертации табличных данных между CSV, JSON и YAML. В этой лабораторной студенты настраивают GitHub Actions
