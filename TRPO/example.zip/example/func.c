#include "func.h"

int func_1(int a, int b)
{
    return a + b;
}
