#include <CUnit/Basic.h>
#include <stdlib.h>
#include "func.h"

static void test_func_1_adds_numbers(void)
{
    CU_ASSERT_EQUAL(func_1(2, 3), 5);
    CU_ASSERT_EQUAL(func_1(-2, 2), 0);
    CU_ASSERT_EQUAL(func_1(0, 0), 0);
}

int main(void)
{
    if (CU_initialize_registry() != CUE_SUCCESS) {
        return EXIT_FAILURE;
    }

    CU_pSuite suite = CU_add_suite("func_1 tests", NULL, NULL);
    if (suite == NULL) {
        CU_cleanup_registry();
        return EXIT_FAILURE;
    }

    if (CU_add_test(suite, "adds integers", test_func_1_adds_numbers) == NULL) {
        CU_cleanup_registry();
        return EXIT_FAILURE;
    }

    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();

    unsigned int failures = CU_get_number_of_failures();
    CU_cleanup_registry();
    return failures == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}
