#ifndef FUNC_H
#define FUNC_H

int func_1(int a, int b);

#endif
