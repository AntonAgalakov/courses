#include <stdio.h>
#include "func.h"

int main(void)
{
    printf("2 + 3 = %d\n", func_1(2, 3));
    return 0;
}
