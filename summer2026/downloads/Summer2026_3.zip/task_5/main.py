import tkinter as tk
import pygame

pygame.mixer.init()

# Громкость по умолчанию 100%
current_volume = 1.0
# Воспроизводящийся звук
current_sound = None


def set_volume(val):
    global current_volume, current_sound
    current_volume = int(val) / 100.0

    if current_sound is not None:
        current_sound.set_volume(current_volume)


def play_cheer():
    global current_sound
    current_sound = pygame.mixer.Sound("cheer.wav")
    current_sound.set_volume(current_volume)
    current_sound.play()


root = tk.Tk()
root.title("Звуковая доска")
root.geometry("300x400")

big_font = ("Arial", 70)

tk.Button(root, text="🎉", command=play_cheer, font=big_font).grid(row=0, column=0, padx=20, pady=20)

# Ползунок громкости внизу
tk.Label(root, text="Громкость").grid(row=2, column=0, columnspan=2, pady=(10, 0))
scale = tk.Scale(root, from_=0, to=100, orient=tk.HORIZONTAL, command=set_volume)
scale.set(100)
scale.grid(row=3, column=0, columnspan=2, padx=20, pady=5)

root.mainloop()