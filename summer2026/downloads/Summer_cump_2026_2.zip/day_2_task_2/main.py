import pygame

# 1. Инициализация
pygame.init()

# 2. Настройки экрана
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Сложный путь к финишу")
clock = pygame.time.Clock()

# 3. Цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (50, 150, 255)
GREEN = (50, 200, 50)
RED = (255, 50, 50)
GRAY = (150, 150, 150)  # Цвет для узких платформ

# 4. Игрок
player = pygame.Rect(30, 540, 40, 40)  # Стоит ровно на земле
speed_x = 0
speed_y = 0
JUMP_FORCE = -12
GRAVITY = 0.6
MOVE_SPEED = 5
on_ground = False

# 5. Уровень: зигзаг + узкие участки
platforms = [
    pygame.Rect(0, 580, 800, 20),  # 1. Земля (старт)
    pygame.Rect(120, 520, 80, 20),  # 2. Первая ступень
    pygame.Rect(280, 460, 60, 20),  # 3. Узкая
    pygame.Rect(420, 400, 100, 20),  # 4. Широкая
    pygame.Rect(290, 340, 50, 20),  # 5. Очень узкая (осторожно!)
    pygame.Rect(150, 280, 90, 20),  # 6. Возврат влево
    pygame.Rect(280, 220, 120, 20),  # 7. Длинная
    pygame.Rect(450, 160, 70, 20),  # 8. Узкая
    pygame.Rect(580, 100, 110, 20),  # 9. Перед финишем
    pygame.Rect(680, 150, 120, 20)  # 10. Подстраховка
]

# 6. Финиш
flag = pygame.Rect(720, 50, 30, 40)
won = False

# 7. Главный цикл
running = True
while running:
    # 7.1. События
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 7.2. Управление
    keys = pygame.key.get_pressed()
    speed_x = 0
    if keys[pygame.K_LEFT]:
        speed_x = -MOVE_SPEED
    if keys[pygame.K_RIGHT]:
        speed_x = MOVE_SPEED
    if keys[pygame.K_SPACE] and on_ground:
        speed_y = JUMP_FORCE
        on_ground = False

    # 7.3. Физика
    speed_y += GRAVITY
    player.x += speed_x
    if player.left < 0: player.left = 0
    if player.right > WIDTH: player.right = WIDTH
    player.y += speed_y

    # 7.4. Коллизии
    on_ground = False
    for plat in platforms:
        if player.colliderect(plat):
            if speed_y > 0 and player.bottom > plat.top:
                player.bottom = plat.top
                speed_y = 0
                on_ground = True

    # Падение в яму → возврат на старт
    if player.top > HEIGHT:
        player.topleft = (30, 540)
        speed_y = 0
        won = False

    # Победа
    if player.colliderect(flag):
        won = True

    # 7.5. Отрисовка
    screen.fill(WHITE)

    # Рисуем платформы: серые = узкие (сложные), чёрные = широкие
    for plat in platforms:
        color = GRAY if plat.width < 70 else BLACK
        pygame.draw.rect(screen, color, plat)

    pygame.draw.rect(screen, RED, flag)
    pygame.draw.rect(screen, BLUE, player)

    if won:
        font = pygame.font.Font(None, 64)
        text = font.render("ПОБЕДА!", True, GREEN)
        screen.blit(text, (WIDTH // 2 - 120, HEIGHT // 2 - 30))

    pygame.display.flip()
    clock.tick(60)

# 8. Завершение
pygame.quit()