import pygame
import random

pygame.init()
screen = pygame.display.set_mode((400, 600))
clock = pygame.time.Clock()

# Загружаем и СРАЗУ масштабируем все картинки
basket_img = pygame.image.load("basket.png").convert_alpha()
basket_img = pygame.transform.scale(basket_img, (80, 50))  # ширина 80, высота 50

apple_img = pygame.image.load("apple.png").convert_alpha()
apple_img = pygame.transform.scale(apple_img, (40, 40))  # квадрат 40x40

banana_img = pygame.image.load("banana.png").convert_alpha()
banana_img = pygame.transform.scale(banana_img, (40, 40))

cherry_img = pygame.image.load("cherry.png").convert_alpha()
cherry_img = pygame.transform.scale(cherry_img, (40, 40))

fruit_images = [apple_img, banana_img, cherry_img]

basket = basket_img.get_rect(center=(200, 550))
fruits = []
score = 0
font = pygame.font.Font(None, 36)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: basket.x -= 5
    if keys[pygame.K_RIGHT]: basket.x += 5
    basket.clamp_ip(pygame.Rect(0, 0, 400, 600))

    if random.randint(0, 40) == 0:
        x = random.randint(20, 380)
        img = random.choice(fruit_images)
        f_rect = img.get_rect(center=(x, -30))  # rect будет правильного размера
        fruits.append([f_rect, img])

    new_fruits = []
    for f_rect, f_img in fruits:
        f_rect.y += 3
        if basket.colliderect(f_rect):
            score += 1
        elif f_rect.top < 600:
            new_fruits.append([f_rect, f_img])
    fruits = new_fruits

    screen.fill((255, 255, 255))
    screen.blit(basket_img, basket)
    for f_rect, f_img in fruits:
        screen.blit(f_img, f_rect)

    text = font.render(f"Счёт: {score}", True, (0, 0, 0))
    screen.blit(text, (10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()